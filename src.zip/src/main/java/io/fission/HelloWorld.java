package io.fission;

import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;

public class HelloWorld implements Function {

    @Override
    public ResponseEntity<?> call(RequestEntity req, Context context) {
        StringBuilder builder = new StringBuilder();

        HashMap data = (HashMap) req.getBody();

        int num_to_invoke = 1;

        // Base case.
        if (data == null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            // Initial N value.
            int N = 2;

            MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
            map.add("N", N + "");

            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity(map, headers);

            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> response = restTemplate.postForEntity("http://router.fission/hello2p", request , String.class );

            String body = response.getBody();

            int total = Integer.parseInt(body) + num_to_invoke;

            // Return the number of tasks invoked by downstream task + number invoked.
            return ResponseEntity.ok("Total number of tasks invoked: " + total);
        }
        else {
            // Since we're using MultiValueMap, the entries are lists...
            ArrayList<String> lst = (ArrayList<String>)data.get("N");
            String N_s = lst.get(0);
            int N = Integer.parseInt(N_s);

            if (N <= 0 ) {
                // We aren't invoking anything so return 0.
                return ResponseEntity.ok(0 + "");
            }
            else {
                int next_n = N - 1;

                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);

                MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
                map.add("N", next_n + "");

                HttpEntity<MultiValueMap<String, String>> request = new HttpEntity(map, headers);

                RestTemplate restTemplate = new RestTemplate();
                ResponseEntity<String> response = restTemplate.postForEntity("http://router.fission/hello2p", request , String.class );

                String body = response.getBody();
                int total = Integer.parseInt(body) + num_to_invoke;

                // Return the number of tasks invoked by downstream task + number invoked.
                return ResponseEntity.ok(total + "");
            }
        }
    }

}